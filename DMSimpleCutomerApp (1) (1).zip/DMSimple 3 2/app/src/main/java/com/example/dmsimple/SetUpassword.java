package com.example.dmsimple;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SetUpassword extends AppCompatActivity {
    EditText set_up_pass_phone, set_up_pass_edit;
    TextView set_up_pass_feedBack_tv;
    Button set_up_pass_bt , skip_password_set_up;
    FirebaseFirestore db;
    FirebaseAuth mAuth;
    private String TAG = "set_up_pass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_upassword);
        set_up_pass_bt = findViewById(R.id.set_up_pass_bt);
        skip_password_set_up = findViewById(R.id.skip_password_set_up);
        set_up_pass_phone = findViewById(R.id.set_up_pass_phone);
        set_up_pass_edit = findViewById(R.id.set_up_pass_edit);
        set_up_pass_feedBack_tv = findViewById(R.id.set_up_pass_feedBack_tv);

        set_up_pass_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Register_User.isValidPass(set_up_pass_edit) &&  Register_User.isValidPass(set_up_pass_phone)){
                    mAuth = FirebaseAuth.getInstance();
                    FirebaseUser u = mAuth.getCurrentUser();
                    u.updatePassword(set_up_pass_edit.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            db = FirebaseFirestore.getInstance();

                            db.collection("users").document(u.getEmail()).update("phone", set_up_pass_phone.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        startActivity(new Intent(getApplicationContext(), DMSimple_Welcome.class));
                                        User my_user = null;
                                        my_user = my_user.getUser(getApplicationContext());
                                        my_user.setPhone(set_up_pass_phone.getText().toString());
                                        my_user.saveUser(getApplicationContext(), my_user);
                                    }else {
                                        SendFeedback("error while setting up password, please try again ");
                                    }
                                }
                            });


                        }
                    });

                }else {
                    SendFeedback("required field empty");
                }
            }
        });

        skip_password_set_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), DMSimple_Welcome.class));
            }
        });
    }

    private void SendFeedback(String message) {
        set_up_pass_feedBack_tv.setText( message);
        set_up_pass_feedBack_tv.setVisibility(View.VISIBLE);

    }

}
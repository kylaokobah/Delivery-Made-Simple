/**
 * Issouf kindo
 * modified from: https://blog.mindorks.com/how-to-add-uber-car-animation-in-android-app
 */
package com.example.dmsimple;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.example.dmsimple.services.FindDriverService;
import com.example.dmsimple.services.TrackingService;
import com.example.dmsimple.utils.DirectionsJSONParser;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;


import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

public class DMSimple_Welcome extends FragmentActivity implements OnMapReadyCallback {

    //declare variables
    GoogleMap map;
    SupportMapFragment mapFragment;
    FloatingActionButton floatingActionButton3;
    String TAG = "DMSimple_Welcome_activity";
    FirebaseFirestore db;
    FirebaseAuth mAuth;
    Location currentLocation =null;
    ArrayList <Drivers> drivers = new ArrayList<>();
    DatabaseReference mDatabase;
    androidx.appcompat.widget.AppCompatButton requestCabButton, cancelRequestCabButton;
    androidx.appcompat.widget.AppCompatTextView statusTextView;
    TextView pickUpTextView;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    private Place pickUpAdd;
    private Place dropOff;
    String current_ride_id;
    Intent serviceIntent;
    private DataUpdateReceiver dataUpdateReceiver;
    private DataUpdateReceiver dataUpdateReceiver2;
    Drivers current_driver = new Drivers();
    View pickUpDropLayout;

    // on new ride riceived
    LatLng currentLatLngFromServer;
    Marker movingCabMarker;
    LatLng previousLatLngFromServer;
    String ride_id = null;
    String current_driver_id =null;
    private LatLng mOrigin =null;
    private LatLng mDestination =null;
    private Polyline mPolyline;
    ArrayList<LatLng> mMarkerPoints;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_m_simple_welcome);
        // from: https://www.tutorialspoint.com/how-to-show-current-location-on-a-google-map-on-android
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLocation();

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        serviceIntent= new Intent(DMSimple_Welcome.this, FindDriverService.class);

        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        if(firebaseUser == null){
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
        requestCabButton = findViewById(R.id.requestCabButton);
        cancelRequestCabButton = findViewById(R.id.cancelRequestCabButton);
        statusTextView = findViewById(R.id.statusTextView);
         pickUpDropLayout = findViewById(R.id.pickUpDropLayout);
        mMarkerPoints = new ArrayList<>();

         // starting up from notification
        Intent intent = getIntent();
        if(intent.getStringExtra("ride_id") != null){
            Log.d(TAG, "Extra: "+intent.getStringExtra("ride_id"));
            ride_id = intent.getStringExtra("ride_id");
            current_driver_id = intent.getStringExtra("driver_id");
            mOrigin =   new LatLng(Double.parseDouble(intent.getStringExtra("pick_up_location_latitude")),
                    Double.parseDouble(intent.getStringExtra("pick_up_location_longitude")));
            mDestination = new LatLng(Double.parseDouble( intent.getStringExtra("drop_off_location_latitude")),
                    Double.parseDouble(    intent.getStringExtra("drop_off_location_longitude")));
            Intent serviceIntent;
            serviceIntent= new Intent(DMSimple_Welcome.this, FindDriverService.class);
            stopService(serviceIntent);

        }else{
            Log.d(TAG, "something went" +
                    "wrong while getting ride_id");
        }




        mDatabase = FirebaseDatabase.getInstance().getReference();
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
//                            Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                            return;
                        }

                        // Get new FCM registration token
                        String token = task.getResult();

//                        // Log and toast
//                        String msg = "notifiction token: " +  token;
//                        Log.d(TAG, msg);
//                        Toast.makeText(DMSimple_Welcome.this, msg, Toast.LENGTH_SHORT).show();

                        User curent_user = new User();
                        curent_user = curent_user.getUser(getApplicationContext());

                        curent_user.saveNotificationToken(DMSimple_Welcome.this, token);
                        saveTodatabase("notification_token", token);
                    }
                });


//search view

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.google_map);


        mapFragment.getMapAsync(this);

        requestCabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newRide();
                cancelRequestCabButton.setVisibility(View.VISIBLE);
//                startActivity(new Intent(getApplicationContext(), NewPickupRequest.class));

            }
        });
        cancelRequestCabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelCurrentRide();
                stopService(serviceIntent);
                cancelRequestCabButton.setVisibility(View.GONE);
                requestCabButton.setVisibility(View.VISIBLE);
                statusTextView.setVisibility(View.GONE);
            }
        });

        String apiKey = getString(R.string.map_key);

        /**
         * Initialize Places. For simplicity, the API key is hard-coded. In a production
         * environment we recommend using a secure mechanism to manage API keys.
         */
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), apiKey);
        }


// Create a new Places client instance.
        PlacesClient placesClient = Places.createClient(this);

        // Initialize the AutocompleteSupportFragment.
        AutocompleteSupportFragment pickUpAutocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.pickUpTextView);

        AutocompleteSupportFragment  dropOffAutocompleteFragment  = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.dropTextView);

        pickUpAutocompleteFragment.setHint("Enter pick up address");
        dropOffAutocompleteFragment.setHint("Enter drop off address");

        pickUpAutocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        dropOffAutocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));

        pickUpAutocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                Log.i(TAG, "Place: " + place.getName() + ", " + place.getId());
                pickUpAdd = place;
            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });

        dropOffAutocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                Log.i(TAG, "Place: " + place.getName() + ", " + place.getId());
                dropOff = place;
                requestCabButton.setVisibility(View.VISIBLE);
            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });




        //BottomSheetDialog bottomSheet = new BottomSheetDialog();
        //bottomSheet.show(getSupportFragmentManager(),
        //"ModalBottomSheet");

//        floatingActionButton3 = findViewById(R.id.floatingActionButton3);
//
//        floatingActionButton3.setOnClickListener(new View.OnClickListener() {
//                                                     @Override
//                                                     public void onClick(View v) {
//                                                         startActivity(new Intent(getApplicationContext(), NewPickupRequest.class));
//                                                     }
//                                                 }
//        );


        //@Override
        //public void onPointerCaptureChanged(boolean hasCapture) {

        //}

        //  }

    /*public void showDialog(){
    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    //dialog.setContentView(R.layout.bottom_sheet_layout);

   LinearLayout btnfloat= dialog.findViewById(R.id.floatingActionButton3);
    LinearLayout shareLocation= dialog.findViewById(R.id.sv_location_in_bottom_sheet_dialog);
    LinearLayout welcome= dialog.findViewById(R.id.welcome_textView);


    btnfloat.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(DMSimple_login.this, "Edit is clicked", Toast.LENGTH_SHORT).show();
        }
    });

    shareLocation.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(DMSimple_login.this, "Edit is clicked", Toast.LENGTH_SHORT).show();
        }

    });


    dialog.show();
    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    dialog.getWindow().getAttributes().windowAnimations= R.style.popAnimation;
    dialog.getWindow().setGravity(Gravity.BOTTOM);*/

//        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                switch (item.getItemId()) {
//                    case R.id.navigation_home:
//                        Toast.makeText(DMSimple_Welcome.this, "Recents", Toast.LENGTH_SHORT).show();
//                        break;
//                    case R.id.navigation_dashboard:
//                        Toast.makeText(DMSimple_Welcome.this, "Favorites", Toast.LENGTH_SHORT).show();
//                        break;
//                    case R.id.navigation_notifications:
//                        Toast.makeText(DMSimple_Welcome.this, "Nearby", Toast.LENGTH_SHORT).show();
//                        break;
//                }
//                return true;
//            }
//        });
    }

    private void saveLocationToDatabase(Double lng, Double lat) {
        //asynchronously retrieve multiple documents

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {

            db.collection("users")
                    .whereEqualTo("email", currentUser.getEmail())
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
//                                    Log.d(TAG, document.getId() + " => " + document.getData());
                                    String id = document.getId().replace("@","__");
                                    id = id.replace(".","_");

                                    mDatabase.child("users").child(id).child("location").setValue( Map.of(
                                            "latitude", lat,
                                            "longitude", lng
                                    ));

                                    db.collection("users").document(document.getId()).update("location", Map.of(
                                            "latitude", lat,
                                            "longitude", lng
                                    )
                                    );
                                }

                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }


    }

    @Override
    protected void onResume() {
        super.onResume();

        if (dataUpdateReceiver == null) dataUpdateReceiver = new DataUpdateReceiver();
        IntentFilter intentFilter = new IntentFilter("driver_on_the_way");
        registerReceiver(dataUpdateReceiver, intentFilter);
        if (dataUpdateReceiver2 == null) dataUpdateReceiver2 = new DataUpdateReceiver();
        IntentFilter intentFilter2 = new IntentFilter("no_driver");
        registerReceiver(dataUpdateReceiver2, intentFilter2);

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (dataUpdateReceiver != null) unregisterReceiver(dataUpdateReceiver);
        if (dataUpdateReceiver2 != null) unregisterReceiver(dataUpdateReceiver2);
    }

    private void saveTodatabase(String notification_token, String token) {
        //asynchronously retrieve multiple documents

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {

            db.collection("users")
                    .whereEqualTo("email", currentUser.getEmail())
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d(TAG, document.getId() + " => " + document.getData());
                                    db.collection("users").document(document.getId()).update("notification_token", token);
                                }

                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }


    }

    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
           Log.d(TAG,"Isue wit permission");
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    saveLocationToDatabase(currentLocation.getLatitude(), currentLocation.getLongitude());
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(DMSimple_Welcome.this);

                }
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
//        if (currentLocation != null) {
            if (mOrigin == null) {
//                LatLng latLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
//                saveLocationToDatabase(currentLocation.getLatitude(), currentLocation.getLongitude());
//
//                MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here!");
//
//                googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
//                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 4));
////            googleMap.addMarker(markerOptions);

                Log.d(TAG, "map ready. drivers... " + drivers.size());
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                getDrivers(googleMap);
                googleMap.setMyLocationEnabled(true);
                //startTrackerService();

            } else{
                // getRideFromDataBase(googleMap);



                // Adding new item to the ArrayList
                mMarkerPoints.add(mOrigin);
                mMarkerPoints.add(mDestination);

                // Creating MarkerOptions
                MarkerOptions options = new MarkerOptions();
                MarkerOptions options2 = new MarkerOptions();
                // Setting the position of the marker
                options.position(mOrigin);
                options2.position(mDestination);

                /**
                 * For the start location, the color of marker is GREEN and
                 * for the end location, the color of marker is RED.
                 */
                options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                options2.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));


                // Add new marker to the Google Map Android API V2
                map.addMarker(options);
                map.addMarker(options2);

                // Checks, whether start and end locations are captured
                if(mMarkerPoints.size() >= 2){
                    mOrigin = mMarkerPoints.get(0);
                    mDestination = mMarkerPoints.get(1);
                    drawRoute();
                    map.animateCamera(CameraUpdateFactory.newLatLng(mOrigin));
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(mOrigin, 10));

                }
            }
            if (current_driver_id != null){ getDriver( map,  current_driver_id);}else {
                Log.d(TAG, "current driver is a gosh...:> " + current_driver_id);

            }



//        }else {
//
//            Log.d(TAG,"Current Location is null");
//        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }

   public void getDrivers(GoogleMap googleMap){
       db.collection("users").whereEqualTo("user_type", "driver").addSnapshotListener(new EventListener<QuerySnapshot>() {
           @Override
           public void onEvent(@Nullable QuerySnapshot value,
                               @Nullable FirebaseFirestoreException e) {
               if (e != null) {
                   Log.w(TAG, "Listen failed.", e);
                   return;
               }
               googleMap.clear();
               for(DocumentSnapshot doc : value){
                   Map<String, String> mylocation = (Map) doc.get("location");
                   String firstname =  doc.getData().get("firstname") != null ? doc.getData().get("firstname").toString() : "";
                   String  email =    doc.getData().get("email") != null ?  doc.getData().get("email").toString(): "";
                   String phone =    doc.getData().get("phone") !=null ?  doc.getData().get("phone").toString(): "";

                   if (mylocation != null ){
                       Log.d(TAG, "location is not null... "+mylocation);

                       Drivers d = new Drivers(firstname ,email ,phone,"", "", mylocation
                               ,doc.getId());
                       String lng = String.valueOf(d.getLocation().get("longitude"));
                       String lat = String.valueOf(d.getLocation().get("latitude"));

                       Marker marker =   addCarMarkerAndGet(new LatLng(Double.parseDouble(lat.toString()),
                               Double.parseDouble(lng.toString())));

                           drivers.add(d);
                           d.setMarker(marker);

                   }else {

                       Log.d(TAG, "not able to show"+  email);
                   }

               }
               Log.d(TAG, "recived rides count"+  drivers.size());

           }
       });

    }

    // show current driver on map
    public void getDriver(GoogleMap googleMap, String driver_id){
        Log.d(TAG, "getting driver");

        db.collection("users").document(driver_id).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {



                if (error != null) {
                    Log.w(TAG, "Listen failed.", error);
                    return;
                }

                DocumentSnapshot doc = value;
                Map<String, String> mylocation = (Map) doc.get("location");
                String firstname =  doc.getData().get("firstname") != null ? doc.getData().get("firstname").toString() : "";
                String  email =    doc.getData().get("email") != null ?  doc.getData().get("email").toString(): "";
                String phone =    doc.getData().get("phone") !=null ?  doc.getData().get("phone").toString(): "";

                if (mylocation != null ){
                    Log.d(TAG, "location is not null... "+mylocation);

                    Drivers d = new Drivers(firstname ,email ,phone,"", "", mylocation
                            ,doc.getId());
                    String lng = String.valueOf(d.getLocation().get("longitude"));
                    String lat = String.valueOf(d.getLocation().get("latitude"));
                    String bearing = String.valueOf(d.getLocation().get("bearing"));
                    currentLatLngFromServer = new LatLng(Double.parseDouble(lat.toString()),
                            Double.parseDouble(lng.toString()));

                    if(bearing != null ){
                        try {
                            updateCabLocation(currentLatLngFromServer, bearing);

                        }catch (Exception e){
                            Log.d(TAG, "no bearing provided");
                        }
                    }else {
                        addCarMarkerAndGet(currentLatLngFromServer);
                    }
                }
            };

        });
    }

    public void  updateCabLocation(LatLng latLng, String bearing) {

        if (movingCabMarker == null) {
            movingCabMarker = addCarMarkerAndGet(latLng);
        }

        if (previousLatLngFromServer == null) {
            currentLatLngFromServer = latLng;
            previousLatLngFromServer = currentLatLngFromServer;
            movingCabMarker.setPosition(currentLatLngFromServer);
            movingCabMarker.setAnchor(0.5f, 0.5f);
            animateCamera(currentLatLngFromServer);
        } else {
            previousLatLngFromServer = currentLatLngFromServer;
            currentLatLngFromServer = latLng;
            Animator valueAnimator = cabAnimator();
            valueAnimator.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {
                    if (currentLatLngFromServer != null && previousLatLngFromServer != null) {
                        long multiplier = animation.getStartDelay();
                        LatLng  nextLocation = new LatLng(
                                multiplier * currentLatLngFromServer.latitude + (1 - multiplier) * previousLatLngFromServer.latitude,
                                multiplier * currentLatLngFromServer.longitude + (1 - multiplier) * previousLatLngFromServer.longitude
                        );
                        movingCabMarker.setPosition(nextLocation);
                        movingCabMarker.setAnchor(0.5f, 0.5f);
                        double rotation = Double.parseDouble(bearing);
                        movingCabMarker.setRotation((float) rotation);
                        animateCamera(nextLocation);
                    }
                }

                @Override
                public void onAnimationEnd(Animator animation) {

                }

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });

            valueAnimator.start();
        }





    }

    public Animator cabAnimator() {
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(0f, 1f);
        valueAnimator.setDuration(3000);
        valueAnimator.setInterpolator(new LinearInterpolator());
        return valueAnimator;
    }

    public Animator PolyLineAnimator() {
        ValueAnimator valueAnimator = ValueAnimator.ofInt(0, 100);
        valueAnimator.setInterpolator(new LinearInterpolator());
        valueAnimator.setDuration(2000);
        return valueAnimator;
    }

    private void animateCamera(LatLng currentLatLngFromServer) {
        CameraPosition cameraPosition = new CameraPosition.Builder().target(currentLatLngFromServer).zoom(15.5f).build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

    }


    private boolean isDriver(Drivers driver){
        Log.d(TAG, " driver count"+  drivers.size());
        for(Drivers d: drivers){
            if(d.getEmail() == driver.getEmail()){
                return true;
            }
        }
        return false;
    }
    private Drivers getDriverByEmail(String email){
        Log.d(TAG, " driver count"+  drivers.size());
        for(Drivers d: drivers){
            if(d.getEmail() == email){
                return d;
            }
        }
        return null;
    }


    private Marker addCarMarkerAndGet(LatLng latLng) {
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromBitmap(getCarBitmap(this));
        return map.addMarker(
                new MarkerOptions().position(latLng).flat(true).icon(bitmapDescriptor)
        );
    }

    private Marker addSimpleMarkerAndGet(LatLng latLng) {
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromBitmap(getSimpleBitmap(this));
        return map.addMarker(
                new MarkerOptions().position(latLng).flat(true).icon(bitmapDescriptor)
        );
    }

    private Bitmap  getOriginDestinationMarkerBitmap( ) {
        int height = 20;
        int width = 20;
        Bitmap bitmap = Bitmap.createBitmap(height, width, Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        canvas.drawRect(0F, 0F, width, height, paint);
        return bitmap;
    }
    public  Bitmap getCarBitmap(Context context)  {
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_car);
        return Bitmap.createScaledBitmap(bitmap, 50, 100, false);
    }

    public  Bitmap getSimpleBitmap(Context context)  {
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.bg_circle_black);
        return Bitmap.createScaledBitmap(bitmap, 50, 100, false);
    }


    //Start the TrackerService//
//
//    private void startTrackerService() {
//        startService(new Intent(this, TrackingService.class));
//        Toast.makeText(this, "GPS tracking enabled", Toast.LENGTH_SHORT).show();
//
//    }

    public void cancelCurrentRide( ) {
        if (current_ride_id != null){
            db.collection("newRides").document(current_ride_id).update("status","cancelled_by_user"
            );
            try {
                db.collection("rides").document(current_ride_id).update("status","cancelled_by_user"
                );
            }catch (Exception e){

            }

        }
    }



        public void newRide( ) {
        if(pickUpAdd !=null  && dropOff != null){

        FirebaseUser user = mAuth.getCurrentUser();
        user.getEmail();
        HashMap<String, Object> ride = new HashMap<String,Object>();
        HashMap<String, String> pick_up_location = new HashMap<String,String>();
        HashMap<String, String> drop_off_location = new HashMap<String,String>();
        ArrayList rejected_drivers_id = new ArrayList();

        pick_up_location.put("longitude",String.valueOf(pickUpAdd.getLatLng().longitude));
        pick_up_location.put("latitude",String.valueOf(pickUpAdd.getLatLng().latitude));
        pick_up_location.put("pickUp_address",pickUpAdd.getName());

        drop_off_location.put("longitude", String.valueOf(dropOff.getLatLng().longitude));
        drop_off_location.put("latitude", String.valueOf(dropOff.getLatLng().latitude));
        drop_off_location.put("dropOff_address",dropOff.getName());

        rejected_drivers_id.add(user.getEmail());
        ride.put("current_driver_id","");
        ride.put("user_id", user.getEmail());
        ride.put("status", "waiting_for_match");
        ride.put("drop_off_location",drop_off_location);
        ride.put("pick_up_location",pick_up_location);
        ride.put("rejected_drivers_id",rejected_drivers_id);
         db.collection("newRides").add(ride).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
             @Override
             public void onSuccess(DocumentReference documentReference) {
                 current_ride_id = documentReference.getId();
                 statusTextView.setVisibility(View.VISIBLE);
                 serviceIntent.putExtra("ride_id", documentReference.getId());
                 serviceIntent.putExtra("pick_up_location_lng", pick_up_location.get("longitude"));
                 serviceIntent.putExtra("pick_up_location_lat", pick_up_location.get("latitude"));

                 startService(serviceIntent);

             }
         }).addOnFailureListener(new OnFailureListener() {
                     @Override
                     public void onFailure(@NonNull Exception e) {
                         Log.w(TAG, "Error adding document", e);
                     }
                 });

        }
    }


    private class DataUpdateReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent.getAction() == "driver_on_the_way") {
                Log.d(TAG, "driver_on_the_way");

                if(intent.getStringExtra("ride_id") != null){
                    Log.d(TAG, "Extra: "+intent.getStringExtra("ride_id"));
                    ride_id = intent.getStringExtra("ride_id");
                    current_driver_id = intent.getStringExtra("driver_id");
                    mOrigin =   new LatLng(Double.parseDouble(intent.getStringExtra("pick_up_location_latitude")),
                            Double.parseDouble(intent.getStringExtra("pick_up_location_longitude")));
                    mDestination = new LatLng(Double.parseDouble( intent.getStringExtra("drop_off_location_latitude")),
                            Double.parseDouble(    intent.getStringExtra("drop_off_location_longitude")));
                    Intent serviceIntent;
                    serviceIntent= new Intent(DMSimple_Welcome.this, FindDriverService.class);
                    stopService(serviceIntent);

                }else{
                    Log.d(TAG, "something went" +
                            "wrong while getting ride_id");
                }

//                showDriverOnTheWay(intent.getStringExtra("current_driver_id"));


            }else if(intent.getAction() == "no_driver" ){

            }
        }
    }

//    private void showDriverOnTheWay( String current_driver_id) {
//        map.clear();
//        pickUpDropLayout.setVisibility(View.GONE);
//        db.collection("users").document(current_driver_id).addSnapshotListener(new EventListener<DocumentSnapshot>() {
//            @Override
//            public void onEvent(@Nullable DocumentSnapshot value,
//                                @Nullable FirebaseFirestoreException e) {
//                if (e != null) {
//                    Log.w(TAG, "Listen failed.", e);
//                    return;
//                }
//
//
//                    Map<String, String> mylocation = (Map) value.get("location");
//                    String firstname =  value.getData().get("firstname") != null ? value.getData().get("firstname").toString() : "";
//                    String  email =    value.getData().get("email") != null ?  value.getData().get("email").toString(): "";
//                    String phone =    value.getData().get("phone") !=null ?  value.getData().get("phone").toString(): "";
//
//                    if (mylocation != null ){
//                        Drivers d = new Drivers(firstname ,email ,phone,"", "", mylocation
//                                ,value.getId());
//                        String lng = String.valueOf(d.getLocation().get("longitude"));
//                        String lat = String.valueOf(d.getLocation().get("latitude"));
//
//                        Marker marker =   addSimpleMarkerAndGet(new LatLng(Double.parseDouble(lat.toString()),
//                                Double.parseDouble(lng.toString())));
//
//                        Polyline polyline1 = map.addPolyline(new PolylineOptions()
//                                .add(
//                                       new  LatLng(Double.parseDouble(lat.toString()),
//                                                Double.parseDouble(lng.toString())),
//                                       pickUpAdd.getLatLng(),
//                                        dropOff.getLatLng()
//                                ));
//
//                        current_driver.setMarker(marker);
//                        current_driver.setFirstname(firstname);
//                        current_driver.setEmail(email);
//                        current_driver.setPhone(phone);
//                        current_driver.setId(value.getId());
//                        current_driver.setLocation(mylocation);
//                        statusTextView.setText(firstname + " is on the way...");
//
//                    }else {
//
//                        Log.d(TAG, "not able to show"+  email);
//                    }
//
//
//            }
//        });
//
//    }


    private void drawRoute(){

        // Getting URL to the Google Directions API
        String url = getDirectionsUrl(mOrigin, mDestination);

        DownloadTask downloadTask = new DownloadTask();

        // Start downloading json data from Google Directions API
        downloadTask.execute(url);
    }


    private String getDirectionsUrl(LatLng origin,LatLng dest){

        // Origin of route
        String str_origin = "origin="+origin.latitude+","+origin.longitude;

        // Destination of route
        String str_dest = "destination="+dest.latitude+","+dest.longitude;

        // Key
        String key = "key=" + getString(R.string.map_key);

        // Building the parameters to the web service
        String parameters = str_origin+"&"+str_dest+"&"+key;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/"+output+"?"+parameters;

        return url;
    }

    /** A method to download json data from url */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try{
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb  = new StringBuffer();

            String line = "";
            while( ( line = br.readLine())  != null){
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        }catch(Exception e){
            Log.d("Exception on download", e.toString());
        }finally{
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    /** A class to download data from Google Directions URL */
    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service
            String data = "";

            try{
                // Fetching the data from web service
                data = downloadUrl(url[0]);
                Log.d("DownloadTask","DownloadTask : " + data);
            }catch(Exception e){
                Log.d("Background Task",e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }


    /** A class to parse the Google Directions in JSON format */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String,String>>> >{

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try{
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);
            }catch(Exception e){
                e.printStackTrace();
            }
            return routes;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;

            // Traversing through all the routes
            for(int i=0;i<result.size();i++){
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();

                // Fetching i-th route
                List<HashMap<String, String>> path = result.get(i);

                // Fetching all the points in i-th route
                for(int j=0;j<path.size();j++){
                    HashMap<String,String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }

                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(8);
                lineOptions.color(Color.RED);
            }

            // Drawing polyline in the Google Map for the i-th route
            if(lineOptions != null) {
                if(mPolyline != null){
                    mPolyline.remove();
                }
                mPolyline = map.addPolyline(lineOptions);

            }else
                Toast.makeText(getApplicationContext(),"No route is found", Toast.LENGTH_LONG).show();
        }
    }


}



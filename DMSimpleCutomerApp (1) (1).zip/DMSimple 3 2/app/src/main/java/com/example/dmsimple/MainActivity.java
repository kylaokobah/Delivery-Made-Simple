package com.example.dmsimple;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;


import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class MainActivity<googleApiClient> extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {


    private EditText editTextEmail;
    private EditText editTextPass;
    private Button btnlogin_norm;
    private Button register;
    private Button new_facebook;
    private Button new_googlebtn;
    boolean valid = true;
    private static final String EMAIL = "email";
    private static final String USER_POSTS = "user_posts";
    private static final String AUTH_TYPE = "rerequest";
    SignInButton google_signInButton;
    private GoogleApiClient googleApiClient;
    private static final int SIGN_IN=1;
    FirebaseFirestore db;
    String TAG = "MainActivity";
    FirebaseAuth mAuth;
    TextView feedBack_tv;
    private boolean emailExist = false;
    private CallbackManager callbackManager;
    private Bundle Extras;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Extras =  getIntent().getExtras();

        if(Extras != null ){
            Log.d(TAG, "Extra: "+Extras);
            Log.d(TAG, "Extra: ride_id "+Extras.getString("ride_id"));
            if (Extras.getString("ride_id") != null){
                Intent i =  new Intent (MainActivity.this, DMSimple_Welcome.class);
                i.putExtra("ride_id",Extras.getString("ride_id"));
                i.putExtra("driver_id",Extras.getString("driver_id"));
                i.putExtra("pick_up_location_latitude",Extras.getString("pick_up_location_latitude"));
                i.putExtra("pick_up_location_longitude",Extras.getString("pick_up_location_longitude"));
                i.putExtra("drop_off_location_latitude",Extras.getString("drop_off_location_latitude"));
                i.putExtra("drop_off_location_longitude",Extras.getString("drop_off_location_longitude"));
                startActivity(i);
                finish();
            }
        }


        GoogleSignInOptions gso= new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("1048071252142-dnhjiu0kc2hsut96hobucgknukbl83ae.apps.googleusercontent.com")
                .requestEmail().build();
        googleApiClient = new GoogleApiClient.Builder( this).enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();


        callbackManager = CallbackManager.Factory.create();

         db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        /*Google Login*/
        google_signInButton=findViewById(R.id.google_login_button);
        new_googlebtn=findViewById(R.id.new_googlebtn);
        new_googlebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (v== new_googlebtn) {
                    google_signInButton.performClick();
                }
                    Intent intent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
                    startActivityForResult(intent, SIGN_IN);

            }
        });


        /*Facebook Login*/
        LoginButton facebook_login_button = findViewById(R.id.facebook_login_button);
        new_facebook = (Button)  findViewById(R.id.new_facebook);
        new_facebook.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            if (view == new_facebook)
                facebook_login_button.performClick();
        }
        });

// Set the initial permissions to request from the user while logging in
        facebook_login_button.setReadPermissions(Arrays.asList(EMAIL,USER_POSTS));
        facebook_login_button.setAuthType(AUTH_TYPE);

// Register a callback to respond to the user
        facebook_login_button.registerCallback(callbackManager,new FacebookCallback<LoginResult>()

            {
                @Override
                public void onSuccess (LoginResult loginResult){

                setResult(RESULT_OK);
                finish();
            }

                @Override
                public void onCancel () {
                setResult(RESULT_CANCELED);
                finish();
            }

                @Override
                public void onError (FacebookException exception){
                // App code
            }
            });


        /*Email Login*/
        //email login with your credentials
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPass = findViewById(R.id.editTextPass);
        btnlogin_norm = (Button) findViewById(R.id.btnlogin_norm);
        feedBack_tv = (TextView) findViewById(R.id.feedBack_tv);
        btnlogin_norm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){

                mAuth.signInWithEmailAndPassword(editTextEmail.getText().toString(), editTextPass.getText().toString())
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    User myuser = new User(user.getDisplayName(),user.getEmail(),  user.getPhoneNumber(), user.getUid(),"");
                                    myuser.saveUser(getApplicationContext(), myuser);
                                    startActivity(new Intent (getApplicationContext(), DMSimple_Welcome.class));

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    Toast.makeText(MainActivity.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                    SendFeedback("Wrong password or email");
                                }
                            }
                        });

            }
        }
        );

        /*Forgot Password*/
        findViewById(R.id.forgot).setOnClickListener(new View.OnClickListener() {

             //calling ForgotPassword class
             @Override
             public void onClick (View v){
                 startActivity(new Intent (getApplicationContext(), ForgotPassword.class));
             }
         }
        );


        /*Create New User*/

        register = (Button) findViewById(R.id.register);
        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {


               //calling register_user class
               @Override
               public void onClick (View v){

                   startActivity(new Intent (getApplicationContext(),Register_User.class));
               }
           }
        );

    }

    private void SendFeedback(String message) {
            feedBack_tv.setText( message);
            feedBack_tv.setVisibility(View.VISIBLE);

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){

        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==SIGN_IN){
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            Log.w(TAG, "c" + result.getStatus());
            if (result.isSuccess()){
                GoogleSignInAccount user = result.getSignInAccount();
                String email =  user.getEmail().toString();
                String name = user.getDisplayName();
                String  id = user.getIdToken();
                HashMap<String, String> myuser = new HashMap<String,String>();
                myuser.put("email", email);
                myuser.put("firstname", name);
                myuser.put("id_token", id);
                myuser.put("user_type", "customer");
                myuser.put("login_type","google_sign_in");

                mAuth.createUserWithEmailAndPassword(email, id)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "createUserWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    if (user != null ) {
                                        // Sign in success, update UI with the signed-in user's information
                                        Log.d(TAG, "signInWithEmail:success");
                                        user = mAuth.getCurrentUser();
                                        User my_user = new User(user.getDisplayName(),user.getEmail(), user.getPhoneNumber(), user.getUid(),"");
                                        my_user.saveUser(getApplicationContext(), my_user);
                                        db.collection("users").document(email).set(myuser);
                                        startActivity(new Intent (getApplicationContext(), SetUpassword.class));

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        Toast.makeText(MainActivity.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();

                                    }


                                }else if (task.getException() instanceof FirebaseAuthUserCollisionException) {

                                    User newUser = new User(name, email, "", user.getIdToken(),"");
                                    newUser.saveUser(getApplicationContext(), newUser);
                                    mAuth.signInWithEmailAndPassword(email,id)
                                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                                @Override
                                                public void onComplete(@NonNull Task<AuthResult> task) {
                                                    if (task.isSuccessful()) {
                                                        // Sign in success, update UI with the signed-in user's information
                                                        Log.d(TAG, "signInWithEmail:success");
                                                        FirebaseUser user = mAuth.getCurrentUser();
                                                        User myuser = new User(user.getDisplayName(),user.getEmail(),  user.getPhoneNumber(), user.getUid(),"");
                                                        myuser.saveUser(getApplicationContext(), myuser);
                                                        startActivity(new Intent (getApplicationContext(), DMSimple_Welcome.class));
                                                    } else {
                                                        // If sign in fails, display a message to the user.
                                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                                        Toast.makeText(MainActivity.this, "Authentication failed.",
                                                                Toast.LENGTH_SHORT).show();

                                                    }
                                                }
                                            });

                                } else {

                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(MainActivity.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });




//                if (!userExist(email)) {
//
//                    mAuth.createUserWithEmailAndPassword(email, user.getId());
//                    User newUser = new User(user.getDisplayName(),user.getEmail(), "", "","");
//                    newUser.saveUser(getApplicationContext(), newUser);
//
//                    db.collection("users").document(email).set(myuser).addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void aVoid) {
//
//                            mAuth.signInWithEmailAndPassword(email,id)
//                                    .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
//                                        @Override
//                                        public void onComplete(@NonNull Task<AuthResult> task) {
//                                            if (task.isSuccessful()) {
//                                                // Sign in success, update UI with the signed-in user's information
//                                                Log.d(TAG, "signInWithEmail:success"+id);
//                                                FirebaseUser user = mAuth.getCurrentUser();
//                                                User myuser = new User(user.getDisplayName(),user.getEmail(),  user.getPhoneNumber(), user.getUid(),"");
//                                                myuser.saveUser(getApplicationContext(), myuser);
//
//                                                startActivity(new Intent (MainActivity.this, DMSimple_Welcome.class));
//                                                finish();
//
//                                            } else {
//                                                // If sign in fails, display a message to the user.
//                                                Log.w(TAG, "signInWithEmail:failure", task.getException());
//                                                Toast.makeText(MainActivity.this, "Authentication failed.",
//                                                        Toast.LENGTH_SHORT).show();
//
//                                            }
//                                        }
//                                    });
//
//
//                            Log.d(TAG, "DocumentSnapshot successfully written!");
//                        }
//                    }).addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//                            Log.w(TAG, "Error writing document", e);
//                        }
//
//                    });
//
//                } else {
//
//                    User newUser = new User(name, email, "", user.getIdToken(),"");
//                    newUser.saveUser(getApplicationContext(), newUser);
//
//                    mAuth.signInWithEmailAndPassword(email,id)
//                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
//                                @Override
//                                public void onComplete(@NonNull Task<AuthResult> task) {
//                                    if (task.isSuccessful()) {
//                                        // Sign in success, update UI with the signed-in user's information
//                                        Log.d(TAG, "signInWithEmail:success");
//                                        FirebaseUser user = mAuth.getCurrentUser();
//                                        User myuser = new User(user.getDisplayName(),user.getEmail(),  user.getPhoneNumber(), user.getUid(),"");
//                                        myuser.saveUser(getApplicationContext(), myuser);
//                                        startActivity(new Intent (getApplicationContext(), DMSimple_Welcome.class));
//                                    } else {
//                                        // If sign in fails, display a message to the user.
//                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
//                                        Toast.makeText(MainActivity.this, "Authentication failed.",
//                                                Toast.LENGTH_SHORT).show();
//
//                                    }
//                                }
//                            });
//
//
//                    Log.d(TAG, "User " + email + " already exists!");
//                    Toast.makeText(MainActivity.this, "Welcome Back", Toast.LENGTH_LONG).show();
//
//                }
//

//                startActivity(new Intent (MainActivity.this, DMSimple_Welcome.class));
//                finish();
            }else {

                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
            }

        }
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent (MainActivity.this, DMSimple_Welcome.class));
            Log.d(TAG, "user exist");
            finish();
        }

//        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
//        if (account!=null){
//            startActivity(new Intent(getApplicationContext(), DMSimple_Welcome.class));
//            finish();
//        }


    }
    protected boolean userExist(String emailEntered){
        DocumentReference docRef = db.collection("users").document(emailEntered);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        emailExist = true;
                        Toast.makeText(getApplicationContext(), "Email address already exist!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Log.d(TAG, "Email checking failed with ", task.getException());
                }
            }

        });
        return emailExist;
    }


}


    //public boolean checkField(EditText textField){


        //if(textField.getText().toString().isEmpty()) {
           // textField.setError("Error");
           // valid = false;
        //}else{
            //valid=true;
        //}
        //return valid;
   // }

//}
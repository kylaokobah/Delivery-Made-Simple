/***
 * Created by Issouf kindo
 * apr 19th, 2021
 */

package com.example.dmsimple.services;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.dmsimple.Drivers;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindDriverService extends Service {

    FirebaseFirestore db;
    FirebaseAuth mAuth;
    ArrayList<Drivers> drivers = new ArrayList<>();
    int index_of_best_driver = -1;
    String best_driver_id = "";
    String TAG = "FindDriverService: ";

    private boolean isRunning  = false;

    @Override
    public void onCreate() {
        super.onCreate();

        Toast.makeText(this, "Service Created", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "Service Created");

        isRunning = true;

    }





    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        Toast.makeText(this, "Searching...", Toast.LENGTH_SHORT).show();
        String ride_id = intent.getStringExtra("ride_id");
        String pick_up_location_lat = intent.getStringExtra("pick_up_location_lng");
        String pick_up_location_lng = intent.getStringExtra("pick_up_location_lng");

        Log.i(TAG, "Service Started with ride ID " + ride_id);

        //Creating new thread for my service
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "Service Started with thread ID " + Thread.currentThread().getId());

                    try {

                        for (int k=0; k<10; k++) {
                            db.collection("newRides").document(ride_id).addSnapshotListener(new EventListener<DocumentSnapshot>() {
                                @Override
                                public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {

                                    String st = value.getString("status");
                                    ArrayList<String> ids = (ArrayList<String>) value.getData().get("rejected_drivers_id");
                                    assert st != null;
                                    if (st.compareToIgnoreCase("waiting_for_match") == 0) {
                                        getDrivers(ride_id, pick_up_location_lng, pick_up_location_lat, ids);
                                    } else if (st.compareToIgnoreCase("waiting_for_pick_up") == 0) {
                                        Intent  intent = new Intent("driver_on_the_way");
                                        intent.putExtra("current_driver_id" , best_driver_id);
                                        sendBroadcast(intent);
                                        stopSelf();
                                    }
                                }


                            });


                            Thread.sleep(25000);
                        }
                    } catch (Exception e) {
                    }

                //Stop service once it finishes its task
                stopSelf();

        }}).start();


        return START_STICKY;
    }

    public void getDrivers(String ride_id, String pick_up_location_lng, String pick_up_location_lat, ArrayList ids){
        Log.d(TAG, " Getting drivers not in ..."+ids);
        index_of_best_driver=-1;

        db.collection("users").whereEqualTo("user_type", "driver").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot documentSnapshots) {
                if (documentSnapshots.isEmpty()) {
                    Log.d(TAG, "onSuccess: LIST EMPTY");
                    return;
                }

                Log.d(TAG, "onSuccess: Calculating ...");

                int i=0;
                Double shortest_dis = Double.POSITIVE_INFINITY;
                for(DocumentSnapshot doc : documentSnapshots){
                    Map<String, String> mylocation = (Map) doc.get("location");
                    String firstname =  doc.getData().get("firstname") != null ? doc.getData().get("firstname").toString() : "";
                    String  email =    doc.getData().get("email") != null ?  doc.getData().get("email").toString(): "";
                    String phone =    doc.getData().get("phone") !=null ?  doc.getData().get("phone").toString(): "";

                    if (mylocation != null ){
                        Log.d(TAG, "location is not null... "+mylocation);

                        Drivers d = new Drivers(firstname ,email ,phone,"", "", mylocation
                                , doc.getId());
                        String lng = String.valueOf(d.getLocation().get("longitude"));
                        String lat = String.valueOf(d.getLocation().get("latitude"));
                        LatLng pick_up = new LatLng(Double.parseDouble(lat), Double.parseDouble(lng));
                        LatLng driver_loc = new LatLng(Double.parseDouble(pick_up_location_lng), Double.parseDouble( pick_up_location_lat));

                        double distance = SphericalUtil.computeDistanceBetween(pick_up, driver_loc);

                       boolean notIn = notIn(d.getEmail(),ids);
                         if (shortest_dis > distance && notIn ){
                             shortest_dis = distance;
                             index_of_best_driver = i;
                             ids.add(d.getEmail());
                             drivers.add(d);
                             Log.d(TAG, "adding... "+d.getEmail());
                         }
                        i++;


                    }else {

                        Log.d(TAG, "not able to show"+  email);
                    }

                }
                if (index_of_best_driver >=0){

                    proposeRideToAdriver(drivers.get(index_of_best_driver),ride_id);
                    best_driver_id = drivers.get(index_of_best_driver).getEmail();
                }else {
                    Intent  intent = new Intent("no_driver");
                    sendBroadcast(intent);
                }
                Log.d(TAG, "recived rides count"+  drivers.size());

            }
        });

    }

    private boolean notIn(String email, ArrayList ids) {
        for(int i = 0 ; i<ids.size();i++){
            if(ids.get(i).toString().compareToIgnoreCase(email)==0)
                return false;
        }
        return true;
    }

    private void proposeRideToAdriver(Drivers driver, String ride_id) {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        Log.d(TAG, "location is not null... "+driver.getEmail());
        String url ="https://us-central1-dmsimple-ce745.cloudfunctions.net/sendRide?new_ride_id="+ride_id+"&drive_id="+driver.getEmail();

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                textView.setText("That didn't work!");
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_SHORT).show();
        isRunning = false;

        Log.i(TAG, "Service Destroyed with thread ID " + Thread.currentThread().getId());
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


}


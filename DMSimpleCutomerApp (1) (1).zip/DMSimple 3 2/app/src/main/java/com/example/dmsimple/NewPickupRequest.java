package com.example.dmsimple;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;

public class NewPickupRequest extends AppCompatActivity {
    EditText full_name,contact_name,contact_number, new_number, dropoff_location;
    Button    btnsend_info;
    FirebaseFirestore db;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_pickup_request);
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        btnsend_info = findViewById(R.id.btnsend_info);

        //send save ride to server
        btnsend_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseUser user = mAuth.getCurrentUser();
                user.getEmail();
                HashMap<String, Object> ride = new HashMap<String,Object>();
                HashMap<String, String> pick_up_location = new HashMap<String,String>();
                HashMap<String, String> drop_off_location = new HashMap<String,String>();
                ArrayList rejected_drivers_id = new ArrayList();

                pick_up_location.put("longitude","0");
                pick_up_location.put("latitude","0");
                drop_off_location.put("longitude", "0");
                drop_off_location.put("latitude", "0");
                rejected_drivers_id.add(user.getUid());
                ride.put("current_driver_id","");
                ride.put("user_id", user.getEmail());
                ride.put("status", "waiting_for_match");
                ride.put("drop_off_location",drop_off_location);
                ride.put("rejected_drivers_id",rejected_drivers_id);
                db.collection("newRides").add(ride);

            }
        });
    }


    private void getActivity() {
    }
    private void dismiss() {
    }

}
